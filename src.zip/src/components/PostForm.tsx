"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import styles from "./PostForm.module.css";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";          // ✔️ GFM만 유지
import { useSession } from "next-auth/react";

type PostFormProps = { postId?: string };

export default function PostForm({ postId }: PostFormProps) {
  const [title, setTitle]     = useState("");
  const [content, setContent] = useState("");
  const [loading, setLoading] = useState(false);
  const router                = useRouter();
  const { data: session, status } = useSession();

  /* --- 제출 핸들러 ---------------------------------- */
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!session || !title || !content) return;

    setLoading(true);
    try {
      const res = await fetch("/api/posts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title, content, author: session.user?.email }),
      });
      if (res.ok) {
        setTitle("");
        setContent("");
        router.push("/");
      }
    } finally {
      setLoading(false);
    }
  };

  /* --- 권한 & 로딩 ---------------------------------- */
  if (status === "loading") return <div>로딩 중...</div>;
  if (!session)
    return <div style={{ margin: 40, textAlign: "center" }}>로그인한 사용자만 글을 작성할 수 있습니다.</div>;

  /* --- 렌더링 --------------------------------------- */
  return (
    <div className={styles.formWrap}>
      {/* ─── 입력 폼 ─────────────────────────────── */}
      <form onSubmit={handleSubmit} className={styles.form}>
        {postId && <div className={styles.editId}>수정할 글 ID: {postId}</div>}
        <input
          className={styles.input}
          placeholder="제목"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          required
        />
        <textarea
          className={styles.textarea}
          placeholder="내용 (마크다운 지원)"
          value={content}
          onChange={(e) => setContent(e.target.value)}
          required
        />
        <button className={styles.button} disabled={loading}>
          {loading ? "작성 중..." : postId ? "글 수정" : "글 작성"}
        </button>
      </form>

      {/* ─── 실시간 미리보기 ─────────────────────── */}
      <div className={styles.previewWrap}>
        <div className={styles.previewTitle}>미리보기</div>
        <div className={styles.previewBox}>
          <ReactMarkdown
            remarkPlugins={[remarkGfm]}
            components={{
              /* 문단: 엔터 2번 이상 → 공백 1em,   엔터 1번 → 줄바꿈 */
              p: ({ node, ...p }) => (
                <p style={{ margin: "1em 0", whiteSpace: "pre-wrap" }}>{p.children}</p>
              ),
              br: () => <br />,                     // 한 줄 엔터
            }}
          >
            {content}
          </ReactMarkdown>
        </div>
      </div>
    </div>
  );
}
