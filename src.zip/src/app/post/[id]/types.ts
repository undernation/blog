export type PostPageProps = {
    params: { id: string };
  };
  