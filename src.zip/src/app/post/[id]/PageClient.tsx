"use client";

import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";      // ✅ GFM만 남김

type PageClientProps = {
  post: {
    _id: string;
    title: string;
    content: string;
    date: string;
    author: string;
  };
};

export default function PageClient({ post }: PageClientProps) {
  const { data: session } = useSession();
  const router            = useRouter();
  const isAuthor          = session?.user?.email === post.author;

  const handleDelete = async () => {
    if (!window.confirm("정말 삭제하시겠습니까?")) return;
    const res = await fetch(`/api/posts/${post._id}`, { method: "DELETE" });
    if (res.ok) {
      alert("삭제되었습니다.");
      router.push("/");
    } else {
      alert("삭제 실패");
    }
  };

  return (
    <div
      style={{
        display: "flex",
        maxWidth: 1100,
        margin: "40px auto",
        background: "#fff",
        borderRadius: 16,
        boxShadow: "0 2px 8px rgba(0,0,0,0.07)",
        padding: 32,
        border: "1px solid #ececec",
      }}
    >
      <div style={{ flex: 1, minWidth: 0 }}>
        {/* ─── 제목 · 날짜 ─────────────────────────────── */}
        <h1 style={{ fontSize: "1.7rem", fontWeight: "bold", marginBottom: 12 }}>
          {post.title}
        </h1>
        <div style={{ color: "#888", fontSize: "0.95rem", marginBottom: 18 }}>
          {post.date}
        </div>

        {/* ─── 작성자만 보이는 버튼 ───────────────────── */}
        {isAuthor && (
          <div style={{ display: "flex", gap: 12, marginBottom: 16 }}>
            <button onClick={handleDelete} style={{ color: "red" }}>
              삭제
            </button>
            <button onClick={() => router.push(`/edit/${post._id}`)}>수정</button>
          </div>
        )}

        {/* ─── 본문 (Markdown) ────────────────────────── */}
        <div style={{ color: "#222", fontSize: "1.1rem", lineHeight: 1.7 }}>
          <ReactMarkdown
            remarkPlugins={[remarkGfm]}
            components={{
              h1: ({ node, ...p }) => (
                <h1
                  style={{
                    fontSize: "2rem",
                    fontWeight: "bold",
                    margin: "32px 0 18px",
                  }}
                >
                  {p.children}
                </h1>
              ),
              h2: ({ node, ...p }) => (
                <h2
                  style={{
                    fontSize: "1.4rem",
                    fontWeight: "bold",
                    margin: "28px 0 14px",
                  }}
                >
                  {p.children}
                </h2>
              ),
              h3: ({ node, ...p }) => (
                <h3
                  style={{
                    fontSize: "1.15rem",
                    fontWeight: "bold",
                    margin: "22px 0 10px",
                  }}
                >
                  {p.children}
                </h3>
              ),
              /* 📌 핵심: <p>에 whiteSpace: pre-wrap */
              p: ({ node, ...p }) => (
                <p style={{ margin: "1em 0", whiteSpace: "pre-wrap" }}>
                  {p.children}
                </p>
              ),
              br: () => <br />,
            }}
          >
            {post.content}
          </ReactMarkdown>
        </div>
      </div>
    </div>
  );
}
